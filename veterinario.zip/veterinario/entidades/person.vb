﻿Public Class person
    Public nombre As String
    Public ci As Integer
    Public telefono As Integer
    Public direccion As String

    Public Sub New(nombre As String, ci As Integer, telefono As Integer, direccion As String)
        Me.nombre = nombre
        Me.ci = ci
        Me.telefono = telefono
        Me.direccion = direccion
    End Sub





End Class
