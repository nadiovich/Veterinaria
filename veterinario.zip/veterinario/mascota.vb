﻿Public Class mascota

End Class